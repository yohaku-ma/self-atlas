SELF ATLAS — 完全版（6診断・合計174問）

【注意】
ChatGPTのファイルプレビューやiPhoneの「ファイル」アプリのクイックルックでは、JavaScriptが制限される場合があります。
その場合、アプリの代わりに「画面がここで止まる場合」という案内が表示されます。

【確実な利用方法：GitHub Pages】
1. GitHubに新しい公開（Public）リポジトリを作成します（例: self-atlas）。
2. index.html をリポジトリのトップ階層にアップロードします。
3. リポジトリの Settings > Pages で、Deploy from a branch / main / (root) を選びます。
4. 公開された https://ユーザー名.github.io/self-atlas/ のURLをSafariまたはChromeで開きます。
5. 質問の回答・診断履歴は、ブラウザ内に保存されます。

【収録内容】
ビッグファイブ30問
エニアグラム36問
恋愛タイプ16 24問
16タイプ＋自己確信 30問
MBTI風・16タイプ24問
強み発見30問

このアプリは各性格モデルに着想を得たオリジナルであり、公式診断ではありません。
